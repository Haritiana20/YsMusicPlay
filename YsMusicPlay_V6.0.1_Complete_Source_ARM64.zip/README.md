# Ys Music Play V6.0.0 — Android 7+ ARM 32-bit

## Configuration de cette révision
- Version Android : `versionName 6.0.0`, `versionCode 60`.
- Android minimum déclaré : API 24 (Android 7.0).
- ABI demandé à Gradle/NDK : `armeabi-v7a` uniquement.
- SDK de compilation : Android 35 ; Java 17 ; NDK 27.2.12479018 ; CMake 3.22.1.

## Modifications intégrées dans cette révision de travail
- Suppression de l'interface et de la logique du minuteur de veille.
- Version À propos mise à jour en 6.0.0.
- Retrait du bouton texte Filaharana en doublon dans le lecteur ; accès à la file conservé par l'icône supérieure.
- Ajout d'un curseur Pitch vidéo de 0,5x à 5,0x avec remise à 1,0x.
- Ajout du choix d'une image de galerie comme arrière-plan, avec conservation de l'URI et option de retrait.
- Ajout d'un mode d'économie de données pour le WebView (chargement des images désactivé et cache privilégié). Cela ne limite pas le débit vidéo YouTube lui-même.
- Workflow GitHub Actions corrigé pour compiler directement le projet et récupérer le moteur natif Demucs.

## Fonctions héritées conservées
- Lecture audio/vidéo Media3, bibliothèque, favoris, file d'attente, répétition, paroles, EQ/Bass Boost et séparation Demucs par fichier.
- Pitch audio 0,5x–5,0x et contrôles de vitesse déjà présents.

## Limites à ne pas masquer
- La lecture YouTube en arrière-plan n'est pas ajoutée : la recherche WebView ne fournit pas cette capacité et l'application ne contourne pas les restrictions de YouTube.
- La localisation de toutes les chaînes de l'application n'est pas encore centralisée ; certaines chaînes restent codées en dur.
- La séparation Demucs est un traitement par fichier, pas un mixage vocal/instrumental en temps réel. Le moteur reste configuré à deux threads pour limiter la pression mémoire ; l'usage de six cœurs n'est pas validé.
- La compatibilité effective du moteur natif Demucs avec `armeabi-v7a` et Android 7 doit être confirmée par le workflow CI. Le réglage Gradle cible cet ABI, mais cela ne constitue pas une preuve de build réussi.
- Aucun build Android ni test matériel n'a été exécuté dans l'environnement de préparation.


## V6.0.1 source update (25 Nov 2026)

- The Now Playing screen keeps the Queue action only as the top Queue icon beside Settings; there is no separate bottom Queue button.
- The EQ, Alvin and Boost controls are constrained to one-line labels so their text does not wrap vertically on narrow screens.
- Separation progress state is posted to the Android main thread. The app reports caught failures in the UI. A native process crash (SIGSEGV/abort) cannot be caught by Kotlin and still requires an Android logcat trace to identify.
- The Demucs Android engine project documentation specifies Android API 29+ and arm64-v8a. This V6.0.1 build configuration therefore targets Android 10+ / ARM64. It does not claim ARM32 or Android 7 support for this native separation engine.
- GitHub Actions workflow builds and verifies the ARM64 native library. This workflow has not yet been run in this environment; a successful APK build is not claimed.
